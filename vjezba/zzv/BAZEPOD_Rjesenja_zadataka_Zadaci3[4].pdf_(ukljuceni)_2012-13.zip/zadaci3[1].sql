CREATE DATABASE zadaci3;

CREATE TABLE student(
  matBr SMALLINT NOT NULL
, ime NCHAR(20) NOT NULL
, prez NCHAR(20) NOT NULL
);
CREATE DISTINCT INDEX idx_student ON student (matBr);

CREATE TABLE predmet(
  sifPred SMALLINT NOT NULL
, nazPred NCHAR(20) NOT NULL
);
CREATE DISTINCT INDEX idx_predmet ON predmet (sifPred);

CREATE TABLE ispit(
  matBr SMALLINT NOT NULL
, sifPred SMALLINT NOT NULL
, datIspit DATE NOT NULL
, ocjena SMALLINT NOT NULL
);
CREATE DISTINCT INDEX idx_ispit ON ispit (matBr, sifPred, datIspit);

INSERT INTO student VALUES (100, 'Ivan', 'Kolar');
INSERT INTO student VALUES (102, 'Ana', 'Horvat');
INSERT INTO student VALUES (105, 'Jura', 'Novak');
INSERT INTO student VALUES (107, 'Ana', 'Ban');

INSERT INTO predmet VALUES (1001, 'Matematika 1');
INSERT INTO predmet VALUES (1002, 'Programiranje');
INSERT INTO predmet VALUES (1003, 'Digitalna logika');

INSERT INTO ispit VALUES (100, 1001, '05.02.2007', 1);
INSERT INTO ispit VALUES (100, 1001, '20.01.2007', 4);
INSERT INTO ispit VALUES (100, 1002, '06.02.2007', 3);
INSERT INTO ispit VALUES (102, 1001, '05.02.2007', 5);
INSERT INTO ispit VALUES (102, 1002, '06.02.2007', 4);
INSERT INTO ispit VALUES (102, 1003, '07.02.2007', 5);
INSERT INTO ispit VALUES (105, 1001, '05.02.2007', 4);
INSERT INTO ispit VALUES (105, 1003, '07.02.2007', 2);
INSERT INTO ispit VALUES (107, 1002, '06.02.2007', 1);

select * from student;
select * from predmet;
select * from ispit;